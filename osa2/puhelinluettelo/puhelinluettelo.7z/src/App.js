import React, { useState, useEffect } from 'react'

import AddPerson from './components/AddPerson'
import PrintPerson from './components/PrintPerson'
import FilterPerson from './components/FilterPerson'
import persondata from './services/persondata'

// const newPerson = (props) => {

//   return (
//   <div>
//       <form onSubmit={props.newPerson}>
//       <div>
//         Name: <input value={props.newName} onChange={props.handleNewName} placeholder="Name here" />
//       </div>
//       <div>
//         Phone: <input value={props.pNum} onChange={props.handleNewPNum} placeholder="0401234567" />
//       </div>
//       <div>
//         <button type="submit">add</button>
//       </div>
//     </form>
//   </div>
//   )
//  }

const App = () => {
  const [ persons, setPersons ] = useState([]) 
  const [ newName, setNewName ] = useState('')
  const [ pNum, setPNum ] = useState('')
  const [ filtr, setFiltr ] = useState('')

  //hakee alkutiedot palvelimelta
  useEffect(() => {
    persondata
      .getAll()
      .then(initialPersons => {
        setPersons(initialPersons)
      })
    // axios
    //   .get('http://localhost:3001/persons')
    //   .then(response => {
    //     setPersons(response.data)
    //   })
  }, [])

  // const addName = (event) => {
  //   setNewName(props)
  // }

  // const match = (element, comp) => element === comp

  // Lisää henkilön tiedot. Mikäli nimi on jo tallennettu, ohjelma ei hyväksy
  const newPerson = (event) => {
    event.preventDefault()
    const personObject = {
      name: newName, number: pNum
    }
    console.log(personObject)
    console.log(persons)
    console.log(persons.some((e) => e.name === personObject.name))

    if (persons.some((e) => e.name.toLowerCase() === personObject.name.toLowerCase())) {
      if (window.confirm(`${newName} is already in phonebook, replace the old numder with a new one?`)) {
        let oldPersonTemp = persons.find(p => p.name.toLowerCase() === personObject.name.toLowerCase())
        let newPersonTemp = {...personObject, pNum}
        console.log(oldPersonTemp)
        persondata
          .update(oldPersonTemp.id, newPersonTemp)
          .then(updatedPerson => {
            setPersons(persons.map(person => person.id !== oldPersonTemp.id ? person : updatedPerson))
          })
      }
    } else {
      // setPersons(persons.concat(personObject))
      // setNewName('')
      persondata
        .create(personObject)
        .then(returnedPerson => {
          setPersons(persons.concat(returnedPerson))
          setNewName('')
          setPNum('')
        })
    }
  }

  const handleNewName = (event) => {
    setNewName(event.target.value)
  }

  const handleNewPNum = (event) => {
    setPNum(event.target.value)
  }

  const handleFilter = (event) => {
    setFiltr(event.target.value)
  }

  const handleDel = (person) => {
    if(window.confirm('Are you sure?')) {
      persondata
      .del(person.id)
      .then(removedPerson => {setPersons(persons.filter(p => p.id!==person.id))})
    }
  }

  return (
    <div>
      <h2>Phonebook</h2>
      <FilterPerson handleFilter={handleFilter} />
      <AddPerson newPerson = {newPerson} handleNewName = {handleNewName} handleNewPNum = {handleNewPNum}
       newName = {newName} pNum = {pNum} />
      <h2>Numbers</h2>
      <div>
          <PrintPerson filtr={filtr} persons={persons} hDel={handleDel} /> 
      </div>
      {/* <div>{persons.map(p =>
        <p key={p.name}>{p.name} {p.phone}</p>)}</div> */}
    </div>
  )
}

export default App